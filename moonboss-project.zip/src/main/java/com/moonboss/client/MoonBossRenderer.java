package com.moonboss.client;

import com.moonboss.MoonBossMod;
import com.moonboss.entity.MoonBossEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class MoonBossRenderer extends MobEntityRenderer<MoonBossEntity, MoonBossModel> {
    private static final Identifier TEXTURE = new Identifier(MoonBossMod.MOD_ID, "textures/entity/moon_boss.png");

    public MoonBossRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new MoonBossModel(ctx.getPart(MoonBossModel.LAYER)), 1.6f);
    }

    @Override
    public Identifier getTexture(MoonBossEntity entity) {
        return TEXTURE;
    }

    // The model is drawn at 2x texture density, so shrink it by half to get 7 blocks.
    @Override
    protected void scale(MoonBossEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(0.5f, 0.5f, 0.5f);
    }
}
