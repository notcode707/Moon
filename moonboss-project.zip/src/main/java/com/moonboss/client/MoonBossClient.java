package com.moonboss.client;

import com.moonboss.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class MoonBossClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(MoonBossModel.LAYER, MoonBossModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.MOON_BOSS, MoonBossRenderer::new);
    }
}
