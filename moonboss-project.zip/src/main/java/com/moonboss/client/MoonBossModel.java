package com.moonboss.client;

import com.moonboss.MoonBossMod;
import com.moonboss.entity.MoonBossEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Model is built at 2x texture density (1 block = 32 units); the renderer scales it by 0.5.
 * Ground is y = 24, total height 224 units = 7 blocks.
 * Every limb hangs down from its joint, and the rest pose (wide stance) is done with rotations.
 */
public class MoonBossModel extends EntityModel<MoonBossEntity> {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier(MoonBossMod.MOD_ID, "moon_boss"), "main");

    private static final float PI = (float) Math.PI;

    // Rest pose angles (radians)
    private static final float THIGH_OUT = 0.838f;   // 48 deg
    private static final float SHIN_IN = 0.751f;     // 43 deg
    private static final float FOOT_FIX = 0.087f;    // 5 deg
    private static final float R_ARM_OUT = 0.68f;    // right arm (viewer left in the image): 39 deg
    private static final float R_FOREARM = 0.14f;
    private static final float L_ARM_OUT = 1.152f;   // left arm raised wider: 66 deg
    private static final float L_FOREARM = 0.349f;

    private final ModelPart root;
    private final ModelPart body, neck, head;
    private final ModelPart rightArm, rightForearm, rightHand;
    private final ModelPart leftArm, leftForearm, leftHand;
    private final ModelPart rightLeg, rightShin, rightFoot;
    private final ModelPart leftLeg, leftShin, leftFoot;

    public MoonBossModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.neck = body.getChild("neck");
        this.head = neck.getChild("head");
        this.rightArm = body.getChild("right_arm");
        this.rightForearm = rightArm.getChild("right_forearm");
        this.rightHand = rightForearm.getChild("right_hand");
        this.leftArm = body.getChild("left_arm");
        this.leftForearm = leftArm.getChild("left_forearm");
        this.leftHand = leftForearm.getChild("left_hand");
        this.rightLeg = root.getChild("right_leg");
        this.rightShin = rightLeg.getChild("right_shin");
        this.rightFoot = rightShin.getChild("right_foot");
        this.leftLeg = root.getChild("left_leg");
        this.leftShin = leftLeg.getChild("left_shin");
        this.leftFoot = leftShin.getChild("left_foot");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();

        // Torso (pelvis + ribcage) at hip height
        ModelPartData body = root.addChild("body",
                ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-12f, -14f, -7f, 24f, 14f, 14f)
                        .uv(80, 0).cuboid(-20f, -62f, -9f, 40f, 48f, 18f),
                ModelTransform.pivot(0f, -83f, 0f));

        // Neck joint + moon head (flat crescent cut out by texture transparency)
        ModelPartData neck = body.addChild("neck",
                ModelPartBuilder.create().uv(200, 0).cuboid(-4f, -12f, -4f, 8f, 12f, 8f),
                ModelTransform.pivot(0f, -62f, 0f));
        neck.addChild("head",
                ModelPartBuilder.create().uv(240, 0).cuboid(-22f, -44f, -2f, 44f, 44f, 4f),
                ModelTransform.pivot(0f, -12f, 0f));

        // Right arm: shoulder -> elbow -> wrist
        ModelPartData rArm = body.addChild("right_arm",
                ModelPartBuilder.create().uv(340, 0).cuboid(-5f, -4f, -5f, 10f, 42f, 10f),
                ModelTransform.pivot(-25f, -56f, 0f));
        ModelPartData rFore = rArm.addChild("right_forearm",
                ModelPartBuilder.create().uv(390, 0).cuboid(-4f, 0f, -4f, 8f, 38f, 8f),
                ModelTransform.pivot(0f, 38f, 0f));
        rFore.addChild("right_hand",
                ModelPartBuilder.create().uv(430, 0).cuboid(-5f, 0f, -6f, 10f, 16f, 12f),
                ModelTransform.pivot(0f, 38f, 0f));

        // Left arm
        ModelPartData lArm = body.addChild("left_arm",
                ModelPartBuilder.create().uv(340, 0).mirrored().cuboid(-5f, -4f, -5f, 10f, 42f, 10f),
                ModelTransform.pivot(25f, -56f, 0f));
        ModelPartData lFore = lArm.addChild("left_forearm",
                ModelPartBuilder.create().uv(390, 0).mirrored().cuboid(-4f, 0f, -4f, 8f, 38f, 8f),
                ModelTransform.pivot(0f, 38f, 0f));
        lFore.addChild("left_hand",
                ModelPartBuilder.create().uv(430, 0).mirrored().cuboid(-5f, 0f, -6f, 10f, 16f, 12f),
                ModelTransform.pivot(0f, 38f, 0f));

        // Right leg: hip -> knee -> ankle
        ModelPartData rLeg = root.addChild("right_leg",
                ModelPartBuilder.create().uv(0, 70).cuboid(-6f, 0f, -6f, 12f, 44f, 12f),
                ModelTransform.pivot(-12f, -83f, 0f));
        ModelPartData rShin = rLeg.addChild("right_shin",
                ModelPartBuilder.create().uv(60, 70).cuboid(-5f, 0f, -5f, 10f, 66f, 10f),
                ModelTransform.pivot(0f, 44f, 0f));
        rShin.addChild("right_foot",
                ModelPartBuilder.create().uv(110, 70).cuboid(-6f, 0f, -16f, 12f, 12f, 22f),
                ModelTransform.pivot(0f, 66f, 0f));

        // Left leg
        ModelPartData lLeg = root.addChild("left_leg",
                ModelPartBuilder.create().uv(0, 70).mirrored().cuboid(-6f, 0f, -6f, 12f, 44f, 12f),
                ModelTransform.pivot(12f, -83f, 0f));
        ModelPartData lShin = lLeg.addChild("left_shin",
                ModelPartBuilder.create().uv(60, 70).mirrored().cuboid(-5f, 0f, -5f, 10f, 66f, 10f),
                ModelTransform.pivot(0f, 44f, 0f));
        lShin.addChild("left_foot",
                ModelPartBuilder.create().uv(110, 70).mirrored().cuboid(-6f, 0f, -16f, 12f, 12f, 22f),
                ModelTransform.pivot(0f, 66f, 0f));

        return TexturedModelData.of(data, 512, 512);
    }

    @Override
    public void setAngles(MoonBossEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        float d = Math.min(limbDistance, 1.0f);   // how fast it is walking
        float p = limbAngle * 0.45f;              // slow, heavy stride

        // ---- Torso: lean, twist, bob, breathing ----
        body.pivotY = -83f - Math.abs(MathHelper.cos(p)) * 3f * d;
        body.pitch = 0.05f + 0.08f * d + MathHelper.sin(animationProgress * 0.05f) * 0.02f;
        body.yaw = MathHelper.cos(p) * 0.12f * d;
        body.roll = MathHelper.sin(p) * 0.04f * d;

        // ---- Neck + head: look at target, keep upright against the torso lean ----
        float yaw = MathHelper.clamp(headYaw, -60f, 60f) * 0.017453292f;
        float pitch = MathHelper.clamp(headPitch, -30f, 30f) * 0.017453292f;
        neck.yaw = yaw * 0.5f - body.yaw * 0.5f;
        neck.pitch = pitch * 0.4f - body.pitch * 0.5f;
        neck.roll = MathHelper.sin(animationProgress * 0.04f) * 0.04f - body.roll;
        head.yaw = yaw * 0.5f - body.yaw * 0.5f;
        head.pitch = pitch * 0.6f - body.pitch * 0.4f;
        head.roll = MathHelper.cos(animationProgress * 0.035f) * 0.05f;

        // ---- Legs: thigh swing, knee bends while the leg moves forward, ankle keeps foot flat ----
        float rSwing = MathHelper.cos(p) * 0.85f * d;
        float lSwing = MathHelper.cos(p + PI) * 0.85f * d;
        rightLeg.pitch = rSwing;
        rightLeg.roll = THIGH_OUT;
        leftLeg.pitch = lSwing;
        leftLeg.roll = -THIGH_OUT;

        rightShin.pitch = Math.max(0f, MathHelper.sin(p)) * 1.0f * d;
        rightShin.roll = -SHIN_IN;
        leftShin.pitch = Math.max(0f, MathHelper.sin(p + PI)) * 1.0f * d;
        leftShin.roll = SHIN_IN;

        rightFoot.pitch = -(rightLeg.pitch + rightShin.pitch) * 0.7f;
        rightFoot.roll = -FOOT_FIX;
        leftFoot.pitch = -(leftLeg.pitch + leftShin.pitch) * 0.7f;
        leftFoot.roll = FOOT_FIX;

        // ---- Arms: opposite to legs; elbow folds when the arm swings forward; wrist trails ----
        float sway = MathHelper.cos(animationProgress * 0.07f) * 0.03f;
        float rArmSwing = MathHelper.cos(p + PI) * 0.55f * d;
        float lArmSwing = MathHelper.cos(p) * 0.55f * d;

        rightArm.pitch = rArmSwing;
        rightArm.roll = R_ARM_OUT + sway;
        rightForearm.pitch = -0.25f + rArmSwing * 0.6f;
        rightForearm.roll = -R_FOREARM;
        rightHand.pitch = 0.1f + 0.25f * MathHelper.cos(p + PI - 0.8f) * d;
        rightHand.roll = 0.1f * MathHelper.sin(p) * d;

        leftArm.pitch = lArmSwing;
        leftArm.roll = -L_ARM_OUT - sway;
        leftForearm.pitch = -0.25f + lArmSwing * 0.6f;
        leftForearm.roll = L_FOREARM;
        leftHand.pitch = 0.1f + 0.25f * MathHelper.cos(p - 0.8f) * d;
        leftHand.roll = -0.1f * MathHelper.sin(p) * d;
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
