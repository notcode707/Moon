package com.moonboss;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class MoonBossMod implements ModInitializer {
    public static final String MOD_ID = "moonboss";

    public static final Item MOON_BOSS_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            new Identifier(MOD_ID, "moon_boss_spawn_egg"),
            new SpawnEggItem(ModEntities.MOON_BOSS, 0xD9A27E, 0x151515, new FabricItemSettings()));

    @Override
    public void onInitialize() {
        ModEntities.register();
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS)
                .register(entries -> entries.add(MOON_BOSS_SPAWN_EGG));
    }
}
