package com.moonboss;

import com.moonboss.entity.MoonBossEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static final EntityType<MoonBossEntity> MOON_BOSS = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(MoonBossMod.MOD_ID, "moon_boss"),
            FabricEntityTypeBuilder.<MoonBossEntity>create(SpawnGroup.MONSTER, MoonBossEntity::new)
                    .dimensions(EntityDimensions.fixed(3.0f, 7.0f))
                    .trackRangeChunks(10)
                    .build());

    public static void register() {
        FabricDefaultAttributeRegistry.register(MOON_BOSS, MoonBossEntity.createBossAttributes());
    }
}
